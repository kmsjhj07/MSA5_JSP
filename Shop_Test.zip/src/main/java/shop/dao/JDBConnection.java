package shop.dao;

public class JDBConnection {

}
